# Nihongo Grand Line

Aplikasi belajar bahasa Jepang Android bertema petualangan bajak laut/anime, dengan palet cream, panel kartu berbayang, dan navigasi modern.

## Fitur
- Home dashboard
- Hiragana & Katakana
- Kosakata Jepang-Indonesia + pencarian
- Quiz interaktif
- XP dan progress lokal
- Tema cream/navy/red/gold
- GitHub Actions untuk membangun APK Debug otomatis

## Build
Android Studio: buka folder proyek lalu Run.

GitHub: push ke branch `main`, lalu workflow **Build Nihongo APK** akan membuat `app-debug.apk` sebagai artifact.

Catatan: proyek memakai visual bertema bajak laut/anime dan tidak menyertakan artwork berhak cipta pihak ketiga.
