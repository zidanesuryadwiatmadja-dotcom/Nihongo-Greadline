package com.nihongo.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Cream = Color(0xFFFFF4D6)
private val Ink = Color(0xFF24211C)
private val Red = Color(0xFFC92B2B)
private val Gold = Color(0xFFE2A62B)
private val Navy = Color(0xFF17324D)
private val Paper = Color(0xFFFFFBF0)

private data class Word(val jp: String, val romaji: String, val id: String, val category: String)
private val words = listOf(
    Word("こんにちは", "Konnichiwa", "Halo", "Salam"),
    Word("ありがとう", "Arigatou", "Terima kasih", "Dasar"),
    Word("すみません", "Sumimasen", "Permisi / maaf", "Dasar"),
    Word("おはよう", "Ohayou", "Selamat pagi", "Dasar"),
    Word("こんばんは", "Konbanwa", "Selamat malam", "Dasar"),
    Word("先生", "Sensei", "Guru", "Sekolah"),
    Word("学生", "Gakusei", "Siswa", "Sekolah"),
    Word("友達", "Tomodachi", "Teman", "Orang"),
    Word("海", "Umi", "Laut", "Petualangan"),
    Word("船", "Fune", "Kapal", "Petualangan"),
    Word("夢", "Yume", "Mimpi", "Petualangan"),
    Word("冒険", "Bouken", "Petualangan", "Petualangan")
)

private val hira = listOf(
    "あ a","い i","う u","え e","お o","か ka","き ki","く ku","け ke","こ ko",
    "さ sa","し shi","す su","せ se","そ so","た ta","ち chi","つ tsu","て te","と to",
    "な na","に ni","ぬ nu","ね ne","の no","は ha","ひ hi","ふ fu","へ he","ほ ho",
    "ま ma","み mi","む mu","め me","も mo","や ya","ゆ yu","よ yo","ら ra","り ri",
    "る ru","れ re","ろ ro","わ wa","を wo","ん n"
)

private val kata = listOf(
    "ア a","イ i","ウ u","エ e","オ o","カ ka","キ ki","ク ku","ケ ke","コ ko",
    "サ sa","シ shi","ス su","セ se","ソ so","タ ta","チ chi","ツ tsu","テ te","ト to",
    "ナ na","ニ ni","ヌ nu","ネ ne","ノ no","ハ ha","ヒ hi","フ fu","ヘ he","ホ ho",
    "マ ma","ミ mi","ム mu","メ me","モ mo","ヤ ya","ユ yu","ヨ yo","ラ ra","リ ri",
    "ル ru","レ re","ロ ro","ワ wa","ヲ wo","ン n"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NihongoApp(this) }
    }
}

@Composable
fun NihongoApp(context: Context) {
    var tab by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(context.getPreferences(0).getInt("score", 0)) }
    var streak by remember { mutableIntStateOf(context.getPreferences(0).getInt("streak", 1)) }
    val save = { newScore: Int ->
        score = newScore
        context.getPreferences(0).edit().putInt("score", newScore).apply()
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Red, secondary = Gold, background = Cream, surface = Paper, onSurface = Ink)) {
        Scaffold(
            containerColor = Cream,
            topBar = { TopBar() },
            bottomBar = {
                NavigationBar(containerColor = Paper) {
                    val items = listOf(
                        Triple("Home", Icons.Default.Home, 0), Triple("Kana", Icons.Default.Translate, 1),
                        Triple("Kotoba", Icons.Default.MenuBook, 2), Triple("Kuis", Icons.Default.Quiz, 3), Triple("Progress", Icons.Default.BarChart, 4)
                    )
                    items.forEach { (label, icon, index) ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Icon(icon, null) }, label = { Text(label) })
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                AnimatedContent(targetState = tab, label = "screen") { page ->
                    when (page) {
                        0 -> Home(score, streak, onQuiz = { tab = 3 }, onKana = { tab = 1 }, onWords = { tab = 2 })
                        1 -> KanaScreen()
                        2 -> Vocabulary()
                        3 -> Quiz(score, save)
                        else -> Progress(score)
                    }
                }
            }
        }
    }
}

@Composable fun TopBar() {
    Row(Modifier.fillMaxWidth().background(Paper).padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("☠️", fontSize = 28.sp)
        Spacer(Modifier.width(10.dp))
        Column { Text("NIHONGO", fontSize = 21.sp, fontWeight = FontWeight.Black, color = Red); Text("Grand Line Study", fontSize = 11.sp, color = Navy) }
        Spacer(Modifier.weight(1f))
        Text("⚓", fontSize = 25.sp)
    }
}

@Composable fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.shadow(7.dp, RoundedCornerShape(18.dp), clip = false).background(Paper, RoundedCornerShape(18.dp)).padding(18.dp), content = content)
}

@Composable fun Home(score: Int, streak: Int, onQuiz: () -> Unit, onKana: () -> Unit, onWords: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Box(Modifier.fillMaxWidth().height(220.dp).background(Brush.linearGradient(listOf(Navy, Color(0xFF285A78), Red)), RoundedCornerShape(24.dp)).padding(22.dp)) {
            Column(Modifier.align(Alignment.BottomStart)) {
                Text("航海日誌 • 学習冒険", color = Color.White.copy(.8f), fontSize = 13.sp)
                Text("Belajar Jepang.\nMulai petualanganmu!", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(10.dp))
                Text("🍖  毎日少しずつ — sedikit setiap hari", color = Color.White)
            }
            Text("☠️", Modifier.align(Alignment.TopEnd), fontSize = 54.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("XP", "$score", Icons.Default.Star, Modifier.weight(1f))
            StatCard("Streak", "$streak hari", Icons.Default.LocalFireDepartment, Modifier.weight(1f))
        }
        Panel(Modifier.fillMaxWidth()) {
            Text("Pilih perjalanan", fontSize = 21.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(12.dp))
            FeatureButton("あ  Hiragana & Katakana", "Kenali 92 karakter dasar", Icons.Default.Translate, onKana)
            FeatureButton("📚  Kotoba", "Kosakata Jepang–Indonesia", Icons.Default.MenuBook, onWords)
            FeatureButton("🧠  Kuis Kapten", "Uji kemampuanmu", Icons.Default.Quiz, onQuiz)
        }
        Text("💡 Tips", fontSize = 20.sp, fontWeight = FontWeight.Black)
        Panel(Modifier.fillMaxWidth()) { Text("Belajar 10–15 menit setiap hari. Ulangi kata yang salah sampai terasa familiar.", color = Ink.copy(.75f), lineHeight = 23.sp) }
    }
}

@Composable fun StatCard(title: String, value: String, icon: ImageVector, modifier: Modifier) =
    Panel(modifier) { Icon(icon, null, tint = Gold); Spacer(Modifier.height(8.dp)); Text(value, fontSize = 25.sp, fontWeight = FontWeight.Black); Text(title, color = Ink.copy(.6f)) }

@Composable fun FeatureButton(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(14.dp), color = Cream) { Icon(icon, null, Modifier.padding(11.dp), tint = Red) }
        Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = Ink.copy(.55f)) }; Text("›", fontSize = 28.sp, color = Red)
    }
}

@Composable fun KanaScreen() {
    var katakana by remember { mutableStateOf(false) }
    val data = if (katakana) kata else hira
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Kana Deck", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Pelajari karakter dasar bahasa Jepang", color = Ink.copy(.6f))
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(!katakana, { katakana = false }, label = { Text("Hiragana") }); FilterChip(katakana, { katakana = true }, label = { Text("Katakana") }) }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), contentPadding = PaddingValues(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(data) { item -> val p = item.split(" "); Panel(Modifier.height(78.dp)) { Text(p[0], fontSize = 25.sp, fontWeight = FontWeight.Black); Text(p[1], color = Red, fontSize = 13.sp) } }
        }
    }
}

@Composable fun Vocabulary() {
    var query by remember { mutableStateOf("") }
    val filtered = words.filter { it.jp.contains(query) || it.romaji.contains(query, true) || it.id.contains(query, true) || it.category.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Kotoba", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Kosakata untuk percakapan sehari-hari", color = Ink.copy(.6f))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Cari kata…") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { w -> Panel { Text(w.jp, fontSize = 25.sp, fontWeight = FontWeight.Black); Text(w.romaji, color = Red); Text(w.id, fontWeight = FontWeight.SemiBold); Text(w.category, fontSize = 11.sp, color = Ink.copy(.5f)) } }
        }
    }
}

@Composable fun Quiz(score: Int, save: (Int) -> Unit) {
    val questions = listOf(
        Triple("ありがとう", "Terima kasih", listOf("Selamat pagi", "Terima kasih", "Permisi")),
        Triple("先生", "Guru", listOf("Guru", "Siswa", "Teman")),
        Triple("海", "Laut", listOf("Kapal", "Laut", "Mimpi")),
        Triple("おはよう", "Selamat pagi", listOf("Selamat malam", "Halo", "Selamat pagi")),
        Triple("友達", "Teman", listOf("Teman", "Guru", "Laut"))
    )
    var index by remember { mutableIntStateOf(0) }
    var local by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("") }
    val q = questions[index]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Kuis Kapten", fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text("Soal ${index + 1} / ${questions.size}", color = Ink.copy(.6f))
        LinearProgressIndicator({ (index + 1) / questions.size.toFloat() }, Modifier.fillMaxWidth())
        Panel(Modifier.fillMaxWidth()) { Text("Apa arti…", color = Ink.copy(.6f)); Text(q.first, fontSize = 43.sp, fontWeight = FontWeight.Black); Text("${q.first}  •  pilih jawabanmu") }
        q.third.forEach { option ->
            val bg = if (answered && option == q.second) Color(0xFFDFF1D8) else if (answered && option == selected) Color(0xFFFFDADA) else Paper
            Surface(Modifier.fillMaxWidth().clickable(enabled = !answered) { selected = option; answered = true; if (option == q.second) local++ }, shape = RoundedCornerShape(15.dp), color = bg, shadowElevation = 3.dp) { Text(option, Modifier.padding(18.dp), fontWeight = FontWeight.SemiBold) }
        }
        if (answered) Button(onClick = { if (index == questions.lastIndex) { save(score + local); index = 0; local = 0 } else index++; selected = ""; answered = false }, Modifier.fillMaxWidth()) { Text(if (index == questions.lastIndex) "Selesai & Simpan XP" else "Soal Berikutnya") }
        Text("XP sesi: $local", fontWeight = FontWeight.Bold, color = Red)
    }
}

@Composable fun Progress(score: Int) {
    val pct = (score.coerceIn(0, 20) / 20f)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("Progress", fontSize = 29.sp, fontWeight = FontWeight.Black)
        Panel(Modifier.fillMaxWidth()) { Text("Level Pelaut", color = Ink.copy(.6f)); Text("${(score / 5) + 1}", fontSize = 52.sp, fontWeight = FontWeight.Black, color = Red); LinearProgressIndicator({ pct }, Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)); Text("$score XP terkumpul") }
        Panel(Modifier.fillMaxWidth()) { Text("Checklist", fontSize = 21.sp, fontWeight = FontWeight.Bold); Check("Hiragana dasar", true); Check("Kosakata dasar", score >= 2); Check("Kuis pertama", score >= 1); Check("Konsisten belajar", score >= 5) }
        Panel(Modifier.fillMaxWidth()) { Text("Target berikutnya", fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("Kumpulkan ${((score / 5 + 1) * 5) - score} XP lagi untuk naik level.") }
    }
}

@Composable fun Check(text: String, done: Boolean) { Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) { Text(if (done) "✓" else "○", color = if (done) Red else Ink.copy(.4f), fontSize = 22.sp); Spacer(Modifier.width(10.dp)); Text(text) } }
